<!DOCTYPE html><html lang="en"><head>
  <meta charset="utf-8">
  <title>Omnitube</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image" href="assets/img/logo_omnitube.png">
<link rel="stylesheet" href="styles.0c70acb9acad81d0.css" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="styles.0c70acb9acad81d0.css"></noscript></head>
<body>
  <app-root></app-root>
<script src="runtime.d7deafc38393512a.js" type="module"></script><script src="polyfills.82d58e3435e8f785.js" type="module"></script><script src="main.3e2c40eda95cc1ba.js" type="module"></script>

</body></html>